#!/usr/bin/env bash
NAME="`cat info | tr -d '1' | tr -d '2' | tr -d '3' | tr -d '4' | tr -d '5' | tr -d '6' | tr -d '7' | tr -d '8' | tr -d '9' | tr -d '0' | tr -d ',' | tr -d '.' | head -1`"
VERSION="`cat info | tr -d 'q' | tr -d 'w'  | tr -d 'e'  | tr -d 'r'  | tr -d 't'  | tr -d 'y'  | tr -d 'u'  | tr -d 'i'  | tr -d 'o'  | tr -d 'p'  | tr -d 'a'  | tr -d 's'  | tr -d 'd'  | tr -d 'f'  | tr -d 'g'  | tr -d 'h'  | tr -d 'j'  | tr -d 'k'  | tr -d 'l'  | tr -d 'z'  | tr -d 'x'  | tr -d 'c'  | tr -d 'v'  | tr -d 'b'  | tr -d 'n'  | tr -d 'm' | tr -d 'Q' | tr -d 'W' | tr -d 'E' | tr -d 'R' | tr -d 'T' | tr -d 'Y' | tr -d 'U' | tr -d 'I' | tr -d 'O' | tr -d 'P' | tr -d 'A' | tr -d 'S' | tr -d 'D' | tr -d 'F' | tr -d 'G' | tr -d 'H' | tr -d 'J' | tr -d 'K' | tr -d 'L' | tr -d 'Z' | tr -d 'X' | tr -d 'C' | tr -d 'V' | tr -d 'B' | tr -d 'N' | tr -d 'M' | head -1`"
GITHUB="`cat info | tail -1`"
AUTHOR="`cat info | tail -2 | head -1`"
ROOT="$HOME/.opcmd"
. root/modules/color
function setup(){
	if [[ "$1" == "-i" ]]; then type="install" ior="installation"; elif [[ "$1" == "-u" ]]; then type="update" ior="update wizard"; else echo "[WINUX / INSTALL:CONSOLE ERROR] Unkown parameter specified to 'setup' function. Please report this bug to $AUTHOR"; fi
	echo "$NAME $VERSION [github: $GITHUB] $ior"
	echo "By installing $NAME, you accept that it will create some files/directories."
	echo "There is no 100% support for $NAME, but any bug will probably repair $AUTHOR (you can contact to $AUTHOR to make bugs repaired)."
	echo -n "Continue [Y/n]? "
	read continue
	case $continue in
		"Y" | "y" | "YES" | "yes") echo "Ok, installing..." ;;
		"N" | "n" | "NO" | "no") echo "Ok, exiting."; exit 0 ;;
		*) echo "Another answer received; exiting. Launch setup again if you mean another option."; exit 0
	esac
	# First (if install): create basic and needed directories&files, to make OpCMD even start-up.
	# First (if update):  update basic and needed directoires&files, don't delete another.
	if [[ $1 == "-i" ]]; then
		mkdir $ROOT
		mkdir $ROOT/commands
		mkdir $ROOT/modules
		mkdir $ROOT/config
		mkdir $ROOT/users
		mkdir $ROOT/.syscmds
	fi
	for i in `ls root/commands`; do
		cp root/commands/$i $ROOT/commands/$i
		chmod u+x $ROOT/commands/$i
	done
	for i in `ls root/modules`; do
		cp root/modules/$i $ROOT/modules/$i
		chmod u+x $ROOT/modules/$i
	done
	for i in `ls root/config`; do
		cp -R root/config/$i $ROOT/config/$i
		chmod u+x $ROOT/config/$i
	done
	for i in `ls root/.syscmds`; do
		cp -R root/.syscmds/$i $ROOT/.syscmds/$i
		chmod u+x $ROOT/.syscmds/$i
	done
	cp root/.start-up $ROOT/.start-up
	cp root/.command $ROOT/.command
	chmod u+x $ROOT/.start-up
	chmod u+x $ROOT/.command
	if [[ $1 == "-i" ]]; then
		$ROOT/.command usermake me
	fi
	echo -n "Do you want to add 'opcmd' command to path [Y/n]? "
	read
	case $REPLY in
		"Y" | "y" | "YES" | "yes") echo 'PATH="$PATH:$HOME/.opcmd/.syscmds"' >> $HOME/.bashrc; echo "Added succesfuly." ;;
		"N" | "n" | "NO" | "no") echo "Ok, continuing without adding." ;;
		*) echo "Another answer received; exiting. If you mean you want to add it to PATH, do: 'PATH=\"\$PATH:\$HOME/.opcmd/.syscmds\" >> \$HOME/.bashrc'."
	esac
	info "Setup is done. Run $ROOT/.syscmds/opcmd to see changes."
}
if [[ -d "$ROOT" ]]; then
	setup -u
else
	setup -i
fi
